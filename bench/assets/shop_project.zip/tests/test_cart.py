from shop.cart import Cart


def test_total():
    c = Cart(); c.add('a', 10); c.add('b', 5)
    assert c.total() == 1500


def test_discount():
    c = Cart(); c.add('a', 200)
    assert c.total(10) == 18000
