from shop.money import to_cents, apply_discount


class Cart:
    def __init__(self):
        self.items = []

    def add(self, name, rub):
        self.items.append((name, to_cents(rub)))

    def total(self, percent=0):
        return apply_discount(sum(c for _, c in self.items), percent)
