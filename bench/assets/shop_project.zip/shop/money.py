def to_cents(rub):
    return int(round(rub * 100))


def apply_discount(cents, percent):
    return cents - cents * percent // 10
